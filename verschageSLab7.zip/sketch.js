let array1 = [];
let array1Copy = [];
let array2 = [];
let array2Copy = [];
let array12 = [];
let randomNum;
let randomSwitch;
let randomNum12;
function setup() {
  createCanvas(1080, 1080);
  textSize(50);
  fill(255, 255, 255);
  for(let i=0; i<5; i++){
    array1[i] = Math.floor(random(1,100));
    array2[i] = Math.floor(random(1,100));
    array2[i+5] = Math.floor(random(1,100));
  }
  array1Copy = [...array1]
  array2Copy = [...array2]
  for (let i=0; i<7; i++){
    randomSwitch = Math.floor(random(0,2));
    if (randomSwitch == 0){
      randomNum = Math.floor(random(0,array1.length));
      array12.push(array1[randomNum]);
      array1.splice(Math.floor(randomNum),1);
    } else {
      randomNum = Math.floor(random(0,array2.length));
      array12.push(array2[randomNum]);
      array2.splice(randomNum,1);  
    }
  }
  console.log(array1);
  console.log(array2);
  console.log(array12);
  randomNum = array1Copy[Math.floor(random(0,5))];
  randomSwitch = array2Copy[Math.floor(random(0,10))];
  randomNum12 = array12[Math.floor(random(0,7))];
}

function draw() {
  background(45);
  text("Array 1: "+array1Copy, 100, 150);
  text("Array 2: "+array2Copy, 100, 300);
  text("Array 1 & 2: "+array12, 100, 450);
  text("Random 1: "+randomNum, 100, 600);
  text("Random 2: "+randomSwitch, 100, 750);
  text("Random 1 & 2: "+randomNum12, 100, 900);
}
function mousePressed() {
  array1 = [];
  array2 = [];
  array12 = [];
  setup()
}