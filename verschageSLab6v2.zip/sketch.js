let bullArray = []; //Array for the bullets that come out of your "ship"
let bullNext = 0;
let asterArray = []; //Array for the asteroids that come from the top of the screen
let asterNext = 0;
let score = 0;
let highScore = 0;
let gameOver = false;
function setup() {
  createCanvas(1080, 1080);
  frameRate(60);
  strokeWeight(3);
  noFill();
  stroke(255, 255, 255);
  textSize(60);
  for (let i=0; i<5; i++){ // sets the bulletArray to default values to avoid an error
    bullArray[i] = [];
    for (let p=0; p<2; p++){
      bullArray[i][p] = -2000
    }
  }
  for (let i=0; i<20; i++){
    asterArray[i] = [];
    for (let p=0; p<6; p++){
      asterArray[i][p] = -10000
    }
  }
  console.log(asterArray);
}

function asteroidSpawn() {
  asterArray[asterNext] = [];
  asterArray[asterNext][0]=random(20,width-20); //starting X position
  asterArray[asterNext][1]=random(-200, -100); //y position
  asterArray[asterNext][2]=random(40,100); //random height
  asterArray[asterNext][3]=random(40,100); //random width
  asterArray[asterNext][4]=random(3, 10); //random speed
  asterArray[asterNext][5]=false
  asterNext++
  if (asterNext>19) {
    asterNext=0
  }
}
function draw() {
  background(0);
  if (gameOver==false){ // makes sure the game is still active before drawing anything
    triangle(mouseX, width-sqrt(width)-80, mouseX-20, width-sqrt(width)-20, mouseX+20, width-sqrt(width)-20); //draws the ship
    for (let i=0; i<5; i++){ //draws the bullets by cycling through the array
      circle(bullArray[i][0], bullArray[i][1], 10)
      bullArray[i][1] = bullArray[i][1]-50; // makes the bullets move up 50px every frame
    }
    for (let i=0; i<20; i++){
      ellipse(asterArray[i][0],asterArray[i][1],asterArray[i][2],asterArray[i][3]); // draws the asteroids every frame
      asterArray[i][1]=asterArray[i][1]+asterArray[i][4]; // adds the asteroids speed every frame
    }
    for (let i=0; i<20; i++){ // collision check
      for (let p=0; p<5; p++){
        if(asterArray[i][0]+asterArray[i][3] >= bullArray[p][0]+10 && asterArray[i][0]-asterArray[i][3] <= bullArray[p][0]-10 && asterArray[i][1]+asterArray[i][2] >= bullArray[p][1]+10 && asterArray[i][1]-asterArray[i][2] <= bullArray[p][1]-10) {
            console.log("boom");
          for(let q=0; q<2; q++) { //moves the asteroid and bullet offscreen
            asterArray[i][q]=-10000
            bullArray[p][q]=-2000 
            }
          score++
          }
       }
    }
    text('Score:', 20, height-20)
    text(score, 200, height-15) // displays the players score on the lower left of the screen
    if (Number.isInteger(frameCount/20)==true) { // Spawns an asteroid 3 times a second
      asteroidSpawn();
      console.log(asterArray);
      for(i=0; i<20; i++) {
        if (asterArray[i][1]>height) {
          gameOver=true
        }
      }
    }
  } else { //displays text when the game is over
    textSize(80);
    text("Game Over", width/2.65, height/2);
    textSize(40);
    text("Score:", width/2.5, height/1.7); 
    text(score, width/1.7, height/1.7);
    text("High Score:", width/2.5, height/1.5); 
    text(highScore, width/1.4, height/1.5);
    if (score>highScore){
      highScore=score;
    }
  }
}
function mouseClicked() { // on mouse click it will set the current spot in the array to the current x and y postion of the ship
    bullArray[bullNext] = [0];
    bullArray[bullNext][0]=mouseX
    bullArray[bullNext][1]=width-sqrt(width)-80
    bullNext++ // cycles to the next spot in the array once the variables are set
    if (bullNext>4) { // sets the array back to 0 if it reaches 5 to avoid to many bullets being drawn
      bullNext=0
    }
  console.log(bullArray);
  if (gameOver == true){ // restarts the game on click if the game is over
    score = 0;
    gameOver = false;
    setup();
  }
}