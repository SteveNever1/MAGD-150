I took this assignment way too far, it was very fun to work on though.

Move the mouse to move the ship, click to shoot.
You can restart by clicking if you get a game over.

I also ported the old library again so it should work out of the box.