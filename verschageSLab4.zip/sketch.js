let ballX; //ball X pos
let ballY; //ball Y pos
let ballV; //ball vertical direction | 0=Left 1=Right
let ballH; //ball horizontal direction | 0=Left 1=Right
let ballS; //ball speed
function setup() {
  createCanvas(1080, 1080); //I coded it so that the canvas is fully adjustable and will still work perfectly
  frameRate(60);
  randomize();
}

function randomize() {
  ballX=random(20,width+20);
  ballY=random(20,height+20);
  ballV=int(random(0,2));
  ballH=int(random(0,2));
  ballV=boolean(ballV); //converting to bool for simplicity
  ballH=boolean(ballH);
  ballS=random(3,10);
  console.log("Vertical", ballV);
  console.log("Horizontal", ballH);
}

function draw() {
  noStroke();
  background(50);
  circle(ballX, ballY, 50);

  if(ballV==1) { //moves the ball on the x axis depending on the speed and direction
    ballX+=ballS;
  } else if (ballV==0) {
    ballX-=ballS;
  } else
    console.log("ballX float error");

    if(ballH==1) { //moves the ball on the y axis depending on the speed and direction
    ballY+=ballS;
  } else if (ballH==0) {
    ballY-=ballS;
  } else
    console.log("ballY float error");

  if (ballX > width-25 || ballX < 25 ) { //checks the wall to see if the ball is offscreen and reverses the direction if true
    ballV=!ballV
    console.log("Offscreen X")
  }
  if (ballY > height-25 || ballY < 25 ) { //checks the ceiling to see if the ball is offscreen and randomizes the ball if true
    randomize();
    console.log("Offscreen Y");
  }
  strokeWeight(5); //green and red walls
  stroke(0, 255, 0);
  line(0, 0, 0, height);
  line(width, 0, width, height);
  stroke(255, 0 ,0);
  line(0, 0, width, 0);
  line(width, height, 0, height);
}